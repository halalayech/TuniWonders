package tests;

import utils.MyDataBase;

public class Main {
    public static void main(String[] args) {
        MyDataBase.getInstance();

    }
}
